/* EP1 - Sistemas Operacionais
 * Parte 1 - SHELL
 * 
 * Nome: Lara Ayumi Nagamatsu               NUSP: 9910568
 * Nome: Lucy Anne de Omena Evangelista     NUSP: 11221776
 * 
 */

// PARA FACILITAR ENTENDIMENTO
#define DU_CMD "/usr/bin/du -hs ." 
#define TRCRT_CMD "/usr/bin/traceroute www.google.com.br"
#define INVAL_OP "Operação inválida.\n"


/* PROTÓTIPOS */
char * definePrompt(); // Criaçao de prompt personalizado